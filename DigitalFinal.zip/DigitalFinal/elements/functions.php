<?php

$output; 

function runQuery($inputQuery) {

    // Run a query (from the function) - example

    /*
    $testQuery = runQuery("SELECT * FROM `Test`"); // returns an array
    echo $testQuery[0];
    */

    $user = 'root';
    $password = 'root';
    $db = 'drivingschool';
    $host = 'localhost';
    $port = 3306;

    $conn = new mysqli($host,$user,$password,$db,$port);

    if ($conn->connect_error) {
        die("<br> Connection failed: " . $conn->connect_error);
        echo " error";
    } 
    else{
        echo "<br> connection successful <br>";
    }

    $sql = $inputQuery;

    $result = $conn->query($sql);

    if (!$result) {
        echo "<br> ERROOOROR";
    }

    $row = $result -> fetch_array();

    $conn-> close();

    return $row;
}


?>